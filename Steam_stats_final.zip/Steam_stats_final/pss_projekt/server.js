const express = require("express");
const fetch = require("node-fetch");

const app = express();
const PORT = 3000;

const STEAM_KEY = "8993386C1F2DD7B5F7B7B54C2724C420";

app.use(express.static(__dirname));
app.use(express.static("public"));


app.get("/profile/:steamid", async (req, res) => {
    try {
        const steamid = req.params.steamid;
       
        const response = await fetch(
            `http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=${STEAM_KEY}&steamids=${steamid}`
        );
        const data = await response.json();
        
       
        res.json(data.response.players[0]);
    } catch (err) {
        console.error("Chyba", err);
        res.status(500).json({ error: "Server error" });
    }
});


app.get("/games/:steamid", async (req, res) => {
    try {
        const steamid = req.params.steamid;
        
        const response = await fetch(
            `https://api.steampowered.com/IPlayerService/GetOwnedGames/v1/?key=${STEAM_KEY}&steamid=${steamid}&include_appinfo=true&include_played_free_games=1`
        );
        const data = await response.json();
        res.json(data);
    } catch (err) {
        console.error("Chyba her:", err);
        res.status(500).json({ error: "Server error" });
    }
});

app.listen(PORT, () => {
    console.log(`Server běží na http://localhost:${PORT}`);
});

app.get("/games/:steamid", async (req, res) => {
    try {
        const steamid = req.params.steamid;
        const url = `https://api.steampowered.com/IPlayerService/GetOwnedGames/v1/?key=${STEAM_KEY}&steamid=${steamid}&include_appinfo=true&include_played_free_games=1`;
        
        const response = await fetch(url);
        const data = await response.json();

        console.log("Počet nalezených her:", data.response.game_count);
        
        res.json(data);
    } catch (err) {
        console.error("Chyba:", err);
        res.status(500).send("Chyba serveru");
    }
});